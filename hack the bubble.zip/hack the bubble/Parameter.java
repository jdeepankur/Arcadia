import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class Parameter {

    public static int day = 1;
    public static int level = 1;
    public static int score = 0;
    public static int time;
    
    public static ArrayList<String> customerRequest = new ArrayList<String>();
    public static ArrayList<String> gameList = new ArrayList<String>();
    public static ArrayList<String> gameName = new ArrayList<String>();
    public static ArrayList<String> gameKeys = new ArrayList<String>();
    private static HashSet<String> KeySet = new HashSet<String>();

    private static String buffer =  new String();


    public static void load() throws IOException {

        //File name = new File("./customer_name.txt");
        //File request = new File("./customer_request.txt");
        File list = new File("./gameList.txt");


        //BufferedReader reader = new BufferedReader(new FileReader(request));
        /*while((buffer = reader.readLine()).length() != 0) {
            customerRequest.add(buffer);
        }
        reader.close();*/

        BufferedReader reader = new BufferedReader(new FileReader(list));
        buffer = reader.readLine();
        do {
            gameList.add(buffer);
            gameName.add(buffer.split(":")[0]);
            gameKeys.add(buffer.split(":")[1]);

            buffer = reader.readLine();
        }while(buffer!=null && buffer.length()!=0);
        
        reader.close();

        for (String s:gameKeys){
            s = s.replace("(" , "");
            s = s.replace(")" , "");
            s = s.replace('|', '&');
            s = s.replaceAll("\\s+","");

            
            KeySet.addAll(Arrays.asList(s.split("&")));

        }
    }

    public static List<String> getKeys() {
        List<String> list = new ArrayList<String>();
        for (String s:KeySet)
            list.add(s);
        return list;
    }
}
