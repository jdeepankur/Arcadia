import java.util.HashSet;
import java.util.Random;

public class CustomerStable {
    public String name = "";
    HashSet<String> interest = new HashSet<String>();

    public CustomerStable(){
        String[] names = { "Dave", "Tom", "Tim", "Max", "Paul", "Susan", "Sarah", "Helen", "Megan", "Laura" };
        int index = (int) Math.floor(Math.random()*10);
        this.name = names[index];
    }

    public String genReq() {
        int number = Parameter.day + Parameter.level;
        for (int i=0; i<number; i++){
            int rnd = new Random().nextInt(Parameter.getKeys().size());
            interest.add(Parameter.getKeys().get(rnd));
            }

        String request = this.name + ": ";
        request += genPrefix() + " ";
        for (String s:interest){
             request += s + ",";
        }
        request += "and economic game.";

        return request;
    }

    private String genPrefix() {
        String[] prefixes = {"I was looking for a",
                "Everyone's talking about a",
        "I don't have a particular favourite but I'm kinda into a",
        "The hottest new idea in game creation is a"};

        int rnd = new Random().nextInt(prefixes.length);
        return prefixes[rnd];
    }

    public float enjoy(HashSet<String> keysPlayed){
        keysPlayed.retainAll(interest);
        return 100*keysPlayed.size()/interest.size();
    }


}

