import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.core.util.RequestPayload;


public class Customer {
    public String name = "";
    HashSet<String> interest = new HashSet<String>();


    public Customer(){
        String[] names = { "Dave", "Tom", "Tim", "Max", "Paul", "Susan", "Sarah", "Helen", "Megan", "Laura" };
        int index = (int) Math.floor(Math.random()*10);
        this.name = names[index];


    }

    public String genReq() throws Exception {
        int level = Parameter.day + Parameter.level;
        boolean flag = true;
        for (int i=0; i<level; i++){
            int rnd = new Random().nextInt(Parameter.getKeys().size());
            interest.add(Parameter.getKeys().get(rnd));
            }

        String request = "";
        for (String s:interest){
            HttpURLConnectionExample http = new HttpURLConnectionExample();

            List<String> synSet = http.searchSynonym(s);

            if(flag) {
                request += genPrefix() + " ";
                flag = false;
            }
            if (synSet!=null){
                int rnd = new Random().nextInt(synSet.size());
                request += synSet.get(rnd) + ", ";
            }
            request += s + ", ";
        }
        request += "and fun.";
        return request;
    }

    private String genPrefix() {
        String[] prefixes = {"I was looking for",
                "Everyone's talking about",
        "I don't have a particular favourite but I'm kinda into",
        "The hottest new idea in game creation is"};

        int rnd = new Random().nextInt(prefixes.length);
        return this.name + ": " + prefixes[rnd];
    }

    public float enjoy(HashSet<String> keysPlayed){
        String bad = this.name + ": This isn't what I want!!!";
        String meidum = this.name + ": This is quite good actually.";
        String good = this.name + ": Wow! That is a great game. Thanks.";
        keysPlayed.retainAll(interest);
        float score = 100*keysPlayed.size()/interest.size();
        if (score < 1) {
            int pointer = 0;
            for (; pointer < bad.toCharArray().length && pointer < 120; pointer++) {
                Display.dialogue[Display.numberOfDialogue][pointer + 1] = bad.toCharArray()[pointer];
            }
        } else if (score < 33) {
            int pointer = 0;
            for (; pointer < meidum.toCharArray().length && pointer < 120; pointer++) {
                Display.dialogue[Display.numberOfDialogue][pointer + 1] = meidum.toCharArray()[pointer];
            }
        } else {
            int pointer = 0;
            for (; pointer < good.toCharArray().length && pointer < 120; pointer++) {
                Display.dialogue[Display.numberOfDialogue][pointer + 1] = good.toCharArray()[pointer];
            }
        }
        String instruction = "--- Press Enter to continue ---";
        Display.numberOfDialogue++;
        int pointer = 0;
            for (; pointer < meidum.toCharArray().length && pointer < 120; pointer++) {
                Display.dialogue[Display.numberOfDialogue][pointer + 1] = meidum.toCharArray()[pointer];
            }
        return score;
    }


}


