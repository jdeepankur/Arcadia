import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;

import javax.swing.MenuElement;

import net.didion.jwnl.JWNLException;

public class Display {//120*41

    private static File template = new File("./Default screen/Template");
    private static File startFormat = new File("./Default screen/Start");
    private static File levelSelectFormat = new File("./Default screen/Level select");
    private static File manualFormat = new File("./Default screen/Manual");
    private static File endFormat = new File("./Default screen/End");
    private static BufferedReader reader;
    private static String buffer;
    private static char[] element;

    private static char[][] screen = new char[41][120];

    private static char[][] logo = new char[7][120];

    public static char[][] dialogue = new char[14][120];
    private static char[][] input = new char[4][61];
    private static char[][] instruction = new char[14][61];
    private static char[][] gameList = new char[18][59];
    private static char[][] scoreAndTime = new char[2][120];

    private static char[][] manual = new char [34][120];
    private static char[][] levelSelect = new char [34][120];


    private static int yIndex;
    private static int xIndex;
    public static int numberOfDialogue = 0;
    private static int choice = 0;

    private static Customer cus = new Customer();

    public static void start() throws Exception {
        loadTemplate();
        loadGame();
        loadManual();

        loadStart();
        loadLevelSelect();
        do {
            loadScreen(choice);
        } while(Parameter.day != 2);

        loadEnd();
    }


    private static void loadTemplate() throws IOException {
        yIndex = 0;
        int index = 0;
        reader = new BufferedReader(new FileReader(template));
        buffer = reader.readLine();
        do {
            xIndex = 0;
            if (index <  7) {
                element = buffer.toCharArray();
                for (int pointer = 0; pointer < 120; pointer++) {
                    logo[yIndex][xIndex] = element[pointer];
                    xIndex++;
                }
                yIndex++;
            } else if (index < 21) {
                element = buffer.toCharArray();
                for (int pointer = 0; pointer < 120; pointer++) {
                    dialogue[yIndex -  7][xIndex] = element[pointer];
                    xIndex++;
                }
                yIndex++;
            } else if (index < 39) {
                if (index < 25) {
                    element = buffer.toCharArray();
                    for (int pointer = 0; pointer < 61; pointer++) {
                        input[yIndex - 21][xIndex] = element[pointer];
                        xIndex++;
                    }
                } else {
                    element = buffer.toCharArray();
                    for (int pointer = 0; pointer < 61; pointer++) {
                        instruction[yIndex - 25][xIndex] = element[pointer];
                        xIndex++;
                    }
                }
                xIndex = 0;
                element = buffer.toCharArray();
                for (int pointer = 61; pointer < 120; pointer++) {
                    gameList[yIndex - 21][xIndex] = element[pointer];
                    xIndex++;
                }
                yIndex++;
            } else {
                element = buffer.toCharArray();
                for (int pointer = 0; pointer < 120; pointer++) {
                    scoreAndTime[yIndex - 39][xIndex] = element[pointer];
                    xIndex++;
                }
                yIndex++;
            }
            index++;
            buffer = reader.readLine();
        } while(buffer != null && buffer.length() != 0);
        reader.close();
    }

    private static void loadStart() throws IOException {
        yIndex = 0;
        for (char[] line : logo) {
            System.out.println(line);
        }
        reader = new BufferedReader(new FileReader(startFormat));
        int index = 1;
        buffer = reader.readLine();
        do {
            if (index > 7) {
                System.out.println(buffer);
            }
            buffer = reader.readLine();
            index++;
        } while(buffer != null && buffer.length() != 0);
        reader.close();
        Input.getInput();
    }

    private static void loadManual() throws IOException, FileNotFoundException {
        yIndex = 0;
        int index = 0;
        reader = new BufferedReader(new FileReader(manualFormat));
        buffer = reader.readLine();
        do {
            if (index > 6) {
                xIndex = 0;
                element = buffer.toCharArray();
                for (int pointer = 0; pointer < 120; pointer++) {
                    manual[yIndex][xIndex] = element[pointer];
                    xIndex++;
                }
                yIndex++;
            }
            index++;
            buffer = reader.readLine();
        } while(buffer != null && buffer.length() != 0);
        yIndex = 2;
        for (int game = 0; game < Parameter.gameList.size(); game++) {
            xIndex = 1;
            int display = game + 1;

            if (display < 10) {
                manual[yIndex][xIndex] = Character.forDigit(display / 10, 10);
                xIndex++;
                manual[yIndex][xIndex] = Character.forDigit(display % 10, 10);
                xIndex++;
            } else {
                manual[yIndex][xIndex] = Character.forDigit(display / 10, 10);
                xIndex++;
                manual[yIndex][xIndex] = Character.forDigit(display % 10, 10);
                xIndex++;
            }
            xIndex++;   // whitespace
            element = Parameter.gameList.get(game).split(":")[0].toCharArray();
            for (int pointer = 0; pointer < element.length; pointer++) {
                manual[yIndex][xIndex] = element[pointer];
                xIndex++;
            }
            yIndex++;
        }
    }

    private static void loadLevelSelect() throws IOException, FileNotFoundException {
        yIndex = 0;
        int index = 0;
        reader = new BufferedReader(new FileReader(levelSelectFormat));
        buffer = reader.readLine();
        do {
            if (index > 6) {
                xIndex = 0;
                element = buffer.toCharArray();
                for (int pointer = 0; pointer < 120; pointer++) {
                    levelSelect[yIndex][xIndex] = element[pointer];
                    xIndex++;
                }
                yIndex++;
            }
            index++;
            buffer = reader.readLine();
        } while(buffer != null && buffer.length() != 0);
        reader.close();
        for (yIndex = 14; yIndex < 18; yIndex++) {
            for (int xIndex = 0; xIndex < 61; xIndex++) {
                levelSelect[yIndex][xIndex] = input[yIndex - 14][xIndex];
            }
        }
        for (char[] line : logo) {
            System.out.println(line);
        }
        for (char[] line : levelSelect) {
            System.out.println(line);
        }
        Parameter.level = Input.getInput();
        if (Parameter.level < 1 || Parameter.level > 4) {
            showError();
            loadLevelSelect();
        }
        clearError();
        Parameter.time = 10;
    }

    private static void loadGame() {
        yIndex = 2;
        for (int game = 0; game < Parameter.gameList.size(); game++) {
            xIndex = 1;
            int display = game + 1;

            if (display < 10) {
                gameList[yIndex][xIndex] = Character.forDigit(display / 10, 10);
                xIndex++;
                gameList[yIndex][xIndex] = Character.forDigit(display % 10, 10);
                xIndex++;
            } else {
                gameList[yIndex][xIndex] = Character.forDigit(display / 10, 10);
                xIndex++;
                gameList[yIndex][xIndex] = Character.forDigit(display % 10, 10);
                xIndex++;
            }
            xIndex++;   // whitespace
            element = Parameter.gameList.get(game).split(":")[0].toCharArray();
            for (int pointer = 0; pointer < element.length; pointer++) {
                gameList[yIndex][xIndex] = element[pointer];
                xIndex++;
            }
            yIndex++;
        }
    }

    public static void loadInput() {
        yIndex = 0;
        xIndex = 8;
        element = Input.buffer.toCharArray();
        for (int pointer = 0; pointer < 61 && pointer < 120; pointer++) {
            input[yIndex][xIndex] = element[pointer];
            xIndex++;
        }
    }

    public static void showError() {
        yIndex = 2;
        xIndex = 1;
        element = "Invalid input --- try again".toCharArray();
        for (int pointer = 0; pointer < 61 && pointer < element.length; pointer++) {
            input[yIndex][xIndex] = element[pointer];
            xIndex++;
        }
    }

    private static void clearError() {
        yIndex = 2;
        xIndex = 1;
        element = "Invalid input --- try again".toCharArray();
        for (int pointer = 0; pointer < 61 && pointer < element.length; pointer++) {
            input[yIndex][xIndex] = ' ';
            xIndex++;
        }
    }

    private static void loadScoreAndTime() {
        yIndex = 0;
        xIndex = 8;
        char[] score = String.valueOf(Parameter.score).toCharArray(); 
        char[] time = String.valueOf(Parameter.time).toCharArray();
        for (int pointer = 0; pointer < score.length; pointer++) {
            scoreAndTime[yIndex][xIndex] = score[pointer];
            xIndex++;
        }
        for (int pointer = 0; pointer < 5; pointer++) {
            scoreAndTime[yIndex][xIndex] = ' ';
            xIndex++;
        }
        xIndex = 67;
        for (int pointer = 0; pointer < time.length; pointer++) {
            scoreAndTime[yIndex][xIndex] = time[pointer];
            xIndex++;
        }
    }

    private static void loadEnd() throws IOException, FileNotFoundException {
        for (char[] line : logo) {
            System.out.println(line);
        }
        reader = new BufferedReader(new FileReader(endFormat));
        int index = 0;
        String buffer = reader.readLine();
        do {
            if (index > 6) {
                System.out.println(buffer);
            }
            index++;
            buffer = reader.readLine();
        } while(buffer != null && buffer.length() != 0);
        reader.close();
        System.out.println(scoreAndTime[0]);
        System.out.println(scoreAndTime[1]);
        System.exit(0);
    }

    private static void loadScreen(int mode) throws Exception {

        switch(mode) {
            case -3:
                break;
            case -2:
                loadScreen(-2);
                clearError();
                break;
            case -1:
                break;
            case 0:
                String request = cus.genReq();
                char[] message = request.toCharArray();
                int pointer = 0;
                while (pointer != message.length) {
                    for (xIndex = 1; pointer < message.length && xIndex < 119; xIndex++) {
                        Display.dialogue[Display.numberOfDialogue][xIndex] = message[pointer];
                    pointer++;
                    }
                    numberOfDialogue++;
                }
                break;
            default:
                String s = Parameter.gameKeys.get(choice-1);
                s = s.replace("(" , "");
                s = s.replace(")" , "");
                s = s.replace('|', '&');
                s = s.replaceAll("\\s+","");
                Parameter.score += cus.enjoy(new HashSet<String>(Arrays.asList(s.split("&"))));
                cus = new Customer();
                numberOfDialogue = 0;
                request = cus.genReq();
                message = request.toCharArray();
                pointer = 0;
                while (pointer != message.length) {
                    for (xIndex = 1; pointer < message.length && xIndex < 119; xIndex++) {
                        Display.dialogue[Display.numberOfDialogue][xIndex] = message[pointer];
                    pointer++;
                    }
                    numberOfDialogue++;
                }
                break;
        }

        loadScoreAndTime();
        yIndex = 0;
        for (; yIndex <  7; yIndex++) {
            for (xIndex = 0; xIndex < 120; xIndex++) {
                screen[yIndex][xIndex] = logo[yIndex][xIndex];
            }
        }
        switch(mode) {
            case -2:
                for (; yIndex < 41; yIndex++) {
                    for (xIndex = 0; xIndex < 120; xIndex++) {
                        screen[yIndex][xIndex] = manual[yIndex - 7][xIndex];
                    }
                }
                break;
            default:
                for (; yIndex < 21; yIndex++) {
                    for (xIndex = 0; xIndex < 120; xIndex++) {
                        screen[yIndex][xIndex] = dialogue[yIndex - 7][xIndex];
                    }
                }
                for (; yIndex < 25; yIndex++) {
                    for (xIndex = 0; xIndex < 120; xIndex++) {
                        if (xIndex < 61) {
                            screen[yIndex][xIndex] = input[yIndex - 21][xIndex];
                        } else {
                            screen[yIndex][xIndex] = gameList[yIndex - 21][xIndex - 61];
                        }
                    }
                }
                for (; yIndex < 39; yIndex++) {
                    for (xIndex = 0; xIndex < 120; xIndex++) {
                        if (xIndex < 61) {
                            screen[yIndex][xIndex] = instruction[yIndex - 25][xIndex];
                        } else {
                            screen[yIndex][xIndex] = gameList[yIndex - 21][xIndex - 61];
                        }
                    }
                }
                for (; yIndex < 41; yIndex++) {
                    for (xIndex = 0; xIndex < 120; xIndex++) {
                        screen[yIndex][xIndex] = scoreAndTime[yIndex - 39][xIndex];
                    }
                }
        }
        
        for (char[] line : screen) {
            System.out.println(line);
        }

        choice = Input.getInput();

        switch(mode) {
            case -3:
            case -2:
            case -1:
            case 0:
                break;
            default:
                Parameter.time += 1;
                if (Parameter.time == 24) {
                    Parameter.day++;
                }
                numberOfDialogue = 0;
                choice = -3;
                break;
        }


    }
}
