import java.io.IOException;

import net.didion.jwnl.JWNLException;

public class Main {

    public static void main(String[] args) throws 
    
    Exception {
        Parameter.load();
        Display.start();
    }
}