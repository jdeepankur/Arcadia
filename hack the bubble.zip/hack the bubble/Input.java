import java.util.Scanner;

public class Input {
    private static Scanner input = new Scanner(System.in);
    public static String buffer;

    public static int getInput() {
        System.out.print(">");
        buffer = input.nextLine();
        int choice = -1;
        if (buffer.length() == 0) {
            return -3;
        }
        if (buffer.equals("s") || buffer.equals("S")){
            return -2;
        }
        try {
            choice = Integer.parseInt(buffer);
            if (choice < 1 || choice > Parameter.gameList.size()) {
                choice = -1;
            }
        }

        catch(NumberFormatException e) {
            Display.showError();
        }

        return choice;
    }
}
